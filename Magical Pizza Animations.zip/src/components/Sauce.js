import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const Sauce = ({ addSauce, pizza }) => {
  const sauces = ['Ketchup', 'Mayonese', 'Mustard'];

  return (
    <motion.div className="base container"
    initial={{ x: '-100vw' }}
      animate={{ x: 0 }}
      transition= {{ type: 'spring', delay: 0.5 , stifness: 300 }}
    
    >

      <h3>Step 2: Choose Your Sauce</h3>
      <ul>
        {sauces.map(sauce => {
          let spanClass = pizza.sauce === sauce ? 'active' : '';
          return (
            <motion.li key={sauce} onClick={() => addSauce(sauce)}
            whileHover = {{ scale: 1.3 , originX: 0 , color:"#FFD700"}}
            transition = {{ type: 'spring', stiffness: 300}}

            >
              <span className={spanClass}>{ sauce }</span>
            </motion.li>
          )
        })}
      </ul>

      {pizza.sauce && (
        <motion.div className="next"
        initial = {{ x: '100vw'}}
        animate = {{ x: 0 }}
        transition = {{ type: 'spring' , stiffness: 120 }}
        
        >
          <Link to="/toppings">
            <motion.button
            whileHover = {{
              scale:1.2,
              textShadow: "0px 0px 8px rgb(255,255,255)",
              boxShadow: "0px 0px 8px rgb(255,255,255)"
    
            }}
            
            >Next</motion.button>
          </Link>
        </motion.div>
      )}

    </motion.div>
  )
}

export default Sauce;