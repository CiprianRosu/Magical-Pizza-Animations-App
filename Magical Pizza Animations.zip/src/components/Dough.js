import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const Dough = ({ addDough, pizza }) => {
  const doughs = ['Classic', 'Thin & Crispy', 'Thick Crust'];

  return (
    <motion.div className="base container"
      initial={{ x: '100vw' }}
      animate={{ x: 0 }}
      transition= {{ type: 'spring', delay: 0.5 , stifness: 300 }}
    
    >

      <h3>Step 1: Choose Your Dough</h3>
      <ul>
        {doughs.map(dough => {
          let spanClass = pizza.dough === dough ? 'active' : '';
          return (
            <motion.li key={dough} onClick={() => addDough(dough)}
            
            whileHover = {{ scale: 1.3 , originX: 0 , color:"#FFD700"}}
            transition = {{ type: 'spring', stiffness: 300}}
            
            >
              <span className={spanClass}>{ dough }</span>
            </motion.li>
          )
        })}
      </ul>

      {pizza.dough && (
        <motion.div className="next"
        initial = {{ x: '-100vw'}}
        animate = {{ x: 0 }}
        transition = {{ type: 'spring' , stiffness: 120 }}


        >
          <Link to="/sauce">
            <motion.button
            whileHover = {{
              scale:1.2,
              textShadow: "0px 0px 8px rgb(255,255,255)",
              boxShadow: "0px 0px 8px rgb(255,255,255)"
    
            }}
            
            >Next</motion.button>
          </Link>
        </motion.div>
      )}

    </motion.div>
  )
}

export default Dough;