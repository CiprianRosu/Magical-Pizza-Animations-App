import React from 'react';
import {motion , AnimatePresence } from 'framer-motion';

const Order = ({ pizza }) => {
  return (
    <div className="container order">
      <motion.h2
        exit={{ y: -1000 }}
      
      >Thank you for your order :)</motion.h2>
      <p>You ordered a {pizza.dough} pizza with {pizza.sauce} and:</p>
      {pizza.toppings.map(topping => <div key={topping}>{topping}</div>)}
    </div>
  )
}

export default Order;